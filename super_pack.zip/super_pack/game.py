import telebot
from telebot import types

import project_data.game.armors as armors
import project_data.game.weapons as weapons
import project_data.game.special_items as special_items
import project_data.game.characters as characters

from project_data.config import bot_token

from project_data.db_talesword.db_operation import *


# region DB
def register_nickname(userid, nickname):
    if db_viewer_nickname(userid):
        insert_nickname_in_table(userid, nickname)
    else:
        edit_nickname_in_table(userid, nickname)


# endregion

# region settings
# telegram bot
bot = telebot.TeleBot(token=bot_token)

# Game
miss_seller = characters.miss_seller
remove = types.ReplyKeyboardRemove()
spells = list()


# endregion


# region telegram_start
@bot.message_handler(commands=['start'])
def telegram_start(message):
    db_reg_user(message.from_user.id)
    save_setting(message.from_user.id)
    save_enemy(message.from_user.id, health=15, status='alive', action='', defence=armors.tattered_clothing.defence)
    save_hero(
        message.from_user.id, weapon_name='Вилы', armor_name='Роба', level=0, health=25, hero_class='Крестьянин',
        expendables='Буханка', cash=0, defence=characters.hero.defence
    )
    save_boss(message.from_user.id, health=30, status='alive', action='', defence=armors.guard_armor.defence)
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    start_game_btn = types.KeyboardButton('Начать игру')
    markup.add(start_game_btn)
    bot.send_message(
        message.chat.id,
        f'Здравствуй, {message.from_user.first_name}! Добро пожаловать в мой мир - Talesworld.\n'
        f'Зови меня сказочником или рассказчиком, сейчас я тебе расскажу одну историю. Готов ли ты?',
        reply_markup=markup
    )


# endregion


@bot.message_handler(commands=['restart'])
def restart(message):
    save_hero(
        message.from_user.id, weapon_name='Вилы', armor_name='Роба', level=0, health=25, hero_class='Крестьянин',
        expendables='Буханка', cash=0, defence=characters.hero.defence
    )
    save_setting(message.from_user.id)
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    start_game_btn = types.KeyboardButton('Начать игру')
    markup.add(start_game_btn)
    bot.send_message(
        message.chat.id,
        f'Кажется, наша история пошла неправильно',
        reply_markup=remove
    )
    bot.send_message(message.chat.id,
                     f'Начнём же сначала, {message.from_user.first_name}?',
                     reply_markup=markup)
    register_nickname(message.from_user.id, '')
    characters.monster = characters.Enemy(health=15, weapon=weapons.monster_fists, name='Монстр',
                                          armor=armors.tattered_clothing,
                                          ability='способностей нет'
                                          )
    enemy = characters.monster
    save_enemy(message.from_user.id, health=enemy.health, defence=enemy.defence,
               status=enemy.status, action=enemy.action)
    characters.guard = characters.Boss(health=30, weapon=weapons.guard_sword, name='Защитник ворот',
                                       armor=armors.guard_armor,
                                       ability='если здоровье меньше 50% - урон увеличивается вдвое'
                                       )
    boss = characters.guard
    save_boss(message.from_user.id, health=boss.health, defence=boss.defence, action=boss.action, status=boss.status)


# region game
@bot.message_handler(content_types=['text'])
def game(message):
    blocks = get_setting(message.from_user.id)
    hero_params = get_hero(message.from_user.id)
    hero = characters.Peasant(
        health=hero_params['health'], weapon=weapons.weapons_name[hero_params['weapon_name']], name=hero_params['name'],
        armor=armors.armors_name[hero_params['armor_name']], hero_class=hero_params['hero_class'], min_block=1,
        max_block=2,
        items=[special_items.items_name[hero_params['expendables']] for _ in range(hero_params['expendables_count'])],
        ability='способностей нет'
    )
    hero.cash = hero_params['cash']
    hero.defence = hero_params['defence']

    if blocks['block_talk_with_guard'] is False:
        enemy_params = get_enemy(message.from_user.id)
        characters.monster.health = enemy_params['health']
        characters.monster.action = enemy_params['action']
        characters.monster.defence = enemy_params['defence']
        characters.monster.status = enemy_params['status']
        enemy = characters.monster
    else:
        boss_params = get_boss(message.from_user.id)
        characters.guard.health = boss_params['health']
        characters.guard.action = boss_params['action']
        characters.guard.defence = boss_params['defence']
        characters.guard.status = boss_params['status']
        enemy = characters.guard

    # region hero_is_dead
    if hero.health <= 0:
        bot.send_message(
            message.chat.id,
            f'Прости, {hero.name}, не смог тебя я защитить.',
            reply_markup=remove
        )
        restart(message)
        return None
    # endregion
    # region /start
    if message.text == 'Начать игру' and blocks['block_start_game'] is False:
        start_game(message)
        save_one_set(message.from_user.id, param='block_start_game', val=True)
    # endregion
    # region name
    if blocks['block_name'] is True and hero.name is None and message.text != 'Начать игру':
        if message.text.isalpha():
            hero.name = message.text
            register_nickname(message.from_user.id, hero.name)
        else:
            hero.name = 'Мистер Крестьянин'
    # endregion
    # region story_start
    if hero.name and blocks['block_story_start'] is False and blocks['block_name'] is True:
        story_start(message)
        save_one_set(message.from_user.id, param='block_story_start', val=True)
    # endregion
    # region start_fight
    if message.text == 'Подойти к Монстру' and blocks['block_fight1'] is False and blocks['block_story_start'] is True:
        if blocks['block_story_start'] is True:
            start_fight(message)
    # endregion
    # region fight
    if blocks['fight_now'] is True:
        # region check_self
        if message.text == 'Проверить своё состояние':
            bot.send_message(
                message.chat.id,
                hero.check_status()
            )
        # endregion
        # region punch
        elif message.text == 'Ударить' or (message.text in spells and type(hero.weapon) == weapons.Staff):
            damage = hero.attack(enemy, message.text)
            if type(hero.weapon) == weapons.MaceWithShield:
                bot.send_message(
                    message.chat.id,
                    f'Ты нанёс {damage} урона! Теперь у {enemy.name} {enemy.health} жизни и {enemy.defence} брони.'
                    f' А у тебя теперь {hero.defence} брони.',
                    reply_markup=remove
                )
            else:
                bot.send_message(
                    message.chat.id,
                    f'Ты нанёс {damage} урона! Теперь у {enemy.name} {enemy.health} жизни и {enemy.defence} брони.',
                    reply_markup=remove
                )
        # endregion
        # region block
        elif message.text == 'Блок':
            block = hero.use_block()
            bot.send_message(
                message.chat.id,
                f'Твоя защита увеличена на {block}!'
            )
            hero.defence += block
        elif message.text == 'Произнести заклинание' and type(hero.weapon) == weapons.Staff:
            spell_cast(message)
        elif message.text == 'Ввести комбинацию' and type(hero.weapon) == weapons.MaceWithShield:
            enter_combination(message)
        elif 'удар' in message.text.split() or 'блок' in message.text.split():
            damage = hero.attack(enemy, message.text)
            bot.send_message(
                message.chat.id,
                f'Ты нанёс {damage} урона! Теперь у {enemy.name} {enemy.health} жизни и {enemy.defence} брони.'
                f' А у тебя теперь {hero.defence} брони.',
                reply_markup=remove
            )
        # endregion
        # todo: доделать инвентарь
        # region inventory
        elif message.text == 'Открыть инвентарь':
            create_inventory(message)
        elif message.text == 'Посмотреть оружие':
            check_weapon(message)
        elif message.text == 'Посмотреть броню':
            check_armor(message)
        elif message.text == 'Посмотреть расходники':
            check_expendables(message)
        elif message.text in hero.name_expendables and blocks['in_inventory']:
            hero.use_expendable(message.text)
            save_one_set(message.from_user.id, param='in_inventory', val=False)
            bot.send_message(
                message.chat.id,
                'Расходник был использован!',
                reply_markup=remove
            )
            bot.send_message(
                message.chat.id,
                'Вернёмся к бою.',
                reply_markup=create_all_battles_btn(message)
            )
        elif message.text == 'Закрыть инвентарь' and blocks['in_inventory']:
            bot.send_message(
                message.chat.id,
                'Хорошо.',
                reply_markup=remove
            )
            bot.send_message(
                message.chat.id,
                'Вернёмся к бою.',
                reply_markup=create_all_battles_btn(message)
            )
            save_one_set(message.from_user.id, param='in_inventory', val=False)
        # endregion
        # region check_enemy
        elif message.text == 'Проверить состояние противника':
            check_enemy(message)
        # endregion
        if message.text == 'Ударить' or message.text == 'Блок' \
                or (message.text in spells and type(hero.weapon) == weapons.Staff) \
                or 'удар' in message.text.split() or 'блок' in message.text.split():
            # region fight_start
            if blocks['first_move']:
                first_move_in_fight(message)
            # endregion
            # region enemy do
            elif enemy.health > 0 and not blocks['first_move']:
                if enemy.action == f'{enemy.name} готовится нанести удар!':
                    enemy_attack(message)
                if enemy.action == f'{enemy.name} готовится защититься.':
                    enemy_attack(message)
                # region enemy think
                enemy.doing()
                bot.send_message(
                    message.chat.id,
                    f'{enemy.action}',
                    reply_markup=create_all_battles_btn(message)
                )
                # endregion
            # endregion
            # region win
            elif enemy.health <= 0:
                with open('project_data/video_and_images/finish_punch.gif', 'rb') as f:
                    bot.send_animation(
                        message.chat.id,
                        f
                    )
                if blocks['block_fight1'] is False:
                    enemy_defeat(message)
                    save_one_set(message.from_user.id, param='block_fight1', val=True)
                else:
                    enemy_defeat(message)
            # endregion
    # endregion
    # region after_first_fight
    if message.text == 'Добить' and (blocks['block_finish_sparing1'] is False or
                                     blocks['block_talk_with_guard'] is True) \
            and (blocks['block_fight1'] is True or blocks['block_talk_with_guard'] is True):
        if blocks['block_talk_with_guard'] is False:
            finish_off_the_enemy1(message)
            save_one_set(message.from_user.id, param='block_finish_sparing1', val=True)
        else:
            finish_off_the_enemy2(message)
            save_one_set(message.from_user.id, param='block_fight2', val=True)
    if message.text == 'Пощадить' and (blocks['block_finish_sparing1'] is False or
                                       blocks['block_talk_with_guard'] is True) \
            and (blocks['block_fight1'] is True or blocks['block_talk_with_guard'] is True):
        if blocks['block_talk_with_guard'] is False:
            spare_the_enemy1(message)
            save_one_set(message.from_user.id, param='block_finish_sparing1', val=True)
        else:
            spare_the_enemy2(message)
            save_one_set(message.from_user.id, param='block_fight2', val=True)
    if message.text == 'Стать магом' and blocks['block_choice_class'] is False and \
            blocks['block_finish_sparing1'] is True:
        become_mage(message)
        save_one_set(message.from_user.id, param='block_choice_class', val=True)
    if message.text == 'Стать воином' and blocks['block_choice_class'] is False and \
            blocks['block_finish_sparing1'] is True:
        become_warrior(message)
        save_one_set(message.from_user.id, param='block_choice_class', val=True)
    # endregion
    # region tavern
    if message.text == 'Идти дальше' and blocks['block_go_to_tavern'] is False and \
            blocks['block_finish_sparing1'] is True:
        go_to_tavern(message)
        save_one_set(message.from_user.id, param='block_go_to_tavern', val=True)
    if message.text == 'Войти в таверну' and blocks['block_tavern'] is False and blocks['block_go_to_tavern'] is True:
        tavern(message)
        save_one_set(message.from_user.id, param='block_tavern', val=True)
    if message.text == 'Спросить, что интересного говорят в последнее время' \
            and blocks['block_question'] is False and blocks['block_tavern'] is True:
        ask(message)
        save_one_set(message.from_user.id, param='block_question', val=True)
    if message.text == 'Посмотреть товар' and blocks['block_view_product'] is False and blocks['block_tavern'] is True:
        view_item(message)
        save_one_set(message.from_user.id, param='block_view_product', val=True)
    if blocks['in_shop']:
        for i in miss_seller.items:
            if message.text == i.name:
                if blocks['way'] == 'murder':
                    if hero.cash >= miss_seller.items[i]:
                        hero.cash -= miss_seller.items[i]
                        if i in weapons.weapons:
                            hero.weapon = i
                        elif i in armors.armors:
                            hero.armor = i
                        elif i in special_items.items:
                            hero.expendables.append(i)
                            hero.name_expendables.append(i.name)
                        bot.send_message(
                            message.chat.id,
                            f'Предмет был куплен.'
                        )
                elif blocks['way'] == 'pacifist':
                    if hero.cash >= miss_seller.items_with_discount[i]:
                        hero.cash -= miss_seller.items_with_discount[i]
                        if i in weapons.weapons:
                            hero.weapon = i
                        elif i in armors.armors:
                            hero.armor = i
                        elif i in special_items.items:
                            hero.expendables.append(i)
                        bot.send_message(
                            message.chat.id,
                            f'Предмет был куплен.'
                        )
    if message.text == 'Уйти из магазина' and blocks['block_tavern'] is True:
        left_shop(message)
        save_one_set(message.from_user.id, param='in_shop', val=False)
    if message.text == 'Пойти к воротам' and blocks['block_tavern'] is True and blocks['in_shop'] is False and \
            blocks['block_talk_with_guard'] is False:
        talk_to_the_guard(message)
        save_one_set(message.from_user.id, param='block_talk_with_guard', val=True)
    # endregion
    save_enemy(message.from_user.id, health=enemy.health, status=enemy.status, action=enemy.action,
               defence=enemy.defence)
    save_boss(message.from_user.id, health=enemy.health, status=enemy.status, action=enemy.action,
              defence=enemy.defence)
    save_hero(message.from_user.id,
              weapon_name=hero.weapon.name,
              armor_name=hero.armor.name,
              level=hero.level,
              health=hero.health,
              hero_class=hero.hero_class,
              expendables=hero.expendables[0].name,
              cash=hero.cash,
              expendables_count=len(hero.expendables),
              defence=hero.defence
              )


# endregion


# region func
def start_game(message):
    bot.send_message(
        message.chat.id,
        '<b>Введи имя счастливца, что станет центром нашей истории</b>',
        parse_mode='html',
        reply_markup=remove
    )
    save_one_set(message.from_user.id, param='block_name', val=True)


def story_start(message):
    hero_par = get_hero(message.from_user.id)
    # region buttons
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    come_up_btn = types.KeyboardButton(f'Подойти к Монстру')
    markup.add(come_up_btn)
    # endregion
    # region text
    bot.send_message(
        message.chat.id,
        'В этих краях давно водились монстры, разбойники и прочая нечисть.\n'
        f'Ты, {hero_par["name"]}, недовольный крестьянин.\n'
        'Тебе нужен король, ведь ты хочешь высказать ему всё, что у тебя накопилось.\n'
        'Для этого ты готов пройти долгий и сложный путь.\n'
        'Но не бойся, на протяжении всего пути я буду с тобой.'
    )
    with open('project_data/video_and_images/village.gif', 'rb') as f:
        bot.send_animation(
            message.chat.id,
            f
        )
    bot.send_message(
        message.chat.id,
        'Итак, пока мы только в "деревне, над которой не садится солнце", а из вещей у тебя только роба, да вилы.\n'
        'Но это ничего, не все великие герои с самого начала были таковыми, так что и тебе не стоит беспокоиться.\n'
        'Главное держись меня, лишь я на твоей стороне.'
    )
    bot.send_message(
        message.chat.id,
        'Смотри, тебе навстречу идёт монстр!\n'
        'Из рассказов, сказок и легенд, ты должен знать, когда монстры приходят в деревни к людям,'
        ' ничем хорошим это не кончается. \n'
        ''
    )
    bot.send_message(
        message.chat.id,
        'Иди, разберись с ним!',
        reply_markup=markup
    )
    # endregion


def start_fight(message):
    hero_par = get_hero(message.from_user.id)
    # region "FIGHT!!!"
    bot.send_message(
        message.chat.id,
        'FIGHT!!!',
        reply_markup=remove
    )
    # endregion
    blocks = get_setting(message.from_user.id)
    # region training
    if blocks['first_fight']:
        bot.send_message(
            message.chat.id,
            f'Краткий экскурс, чтобы не умереть в самом начале наше великого пути:\n'
            f'1) первом делом, советую посмотреть свои показатели и показатели врага,'
            f' а то можно попасть в неловкую ситуацию\n'
            f'2) балансируй между атакой и защитой - это важно\n'
            f'3) не забывай использовать расходники, в случае чего они спасут твою жизнь'
        )
    save_one_set(message.from_user.id, param='first_fight', val=False)
    # endregion
    bot.send_message(
        message.chat.id,
        f'Что же ты сделаешь, {hero_par["name"]}?',
        reply_markup=create_all_battles_btn(message)
    )
    save_one_set(message.from_user.id, param='fight_now', val=True)


def finish_off_the_enemy1(message):
    hero_par = get_hero(message.from_user.id)
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    mage = types.KeyboardButton('Стать магом')
    warrior = types.KeyboardButton('Стать воином')
    enemy.status = 'dead'
    save_one_set(message.from_user.id, param='way', val='murder')
    bot.send_message(
        message.chat.id,
        f'Ты добил монстра.',
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        f'Поздравляю, {hero_par["name"]}, ты стал ближе к тому, чтобы стать НАСТОЯЩИМ героем!',
    )
    bot.send_message(
        message.chat.id,
        f'Уровень повышен на 1.',
    )
    markup.add(mage, warrior)
    bot.send_message(
        message.chat.id,
        f'И теперь ты можешь выбрать себе класс и получить новое оружие!',
        reply_markup=markup
    )


def spare_the_enemy1(message):
    hero_params = get_hero(message.from_user.id)
    hero = characters.Peasant(
        health=hero_params['health'], weapon=weapons.weapons_name[hero_params['weapon_name']], name=hero_params['name'],
        armor=armors.armors_name[hero_params['armor_name']], hero_class=hero_params['hero_class'], min_block=1,
        max_block=2,
        items=[special_items.items_name[hero_params['expendables']] for _ in range(hero_params['expendables_count'])],
        ability='способностей нет'
    )
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    go_btn = types.KeyboardButton('Идти дальше')
    bot.send_message(
        message.chat.id,
        f'{hero_params["name"]}: У меня не было выбора {enemy.name},'
        f' но теперь, когда он у меня есть, я не стану тебя добивать тебя.',
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        f'{enemy.name}: я понимаю, ты ведь герой. Вот, держи, мне не жалко.',
    )
    hero.expendables.append(special_items.loaf)
    save_one_hero(message.from_user.id, 'expendables_count', hero_params['expendables_count'] + 1)
    bot.send_message(
        message.chat.id,
        f'Получен предмет *Буханка*!',
    )
    bot.send_message(
        message.chat.id,
        f'...',
    )
    markup.add(go_btn)
    bot.send_message(
        message.chat.id,
        f'Что ж, {hero_params["name"]}, твой уровень повысился на 0.\n'
        f'В этот раз ты не смог стать настоящим героем, но у тебя ещё будет возможность.',
        reply_markup=markup
    )


# todo: доделать
def become_mage(message):
    hero_params = get_hero(message.from_user.id)
    hero = characters.Peasant(
        health=hero_params['health'], weapon=weapons.weapons_name[hero_params['weapon_name']], name=hero_params['name'],
        armor=armors.armors_name[hero_params['armor_name']], hero_class=hero_params['hero_class'], min_block=1,
        max_block=2,
        items=[special_items.items_name[hero_params['expendables']] for _ in range(hero_params['expendables_count'])],
        ability='способностей нет'
    )
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    go_btn = types.KeyboardButton('Идти дальше')
    bot.send_message(
        message.chat.id,
        f'Теперь ты маг 1 уровня!',
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        f'Получены новые предметы: Палка ботаника и Роба мага!',
    )
    markup.add(go_btn)
    bot.send_message(
        message.chat.id,
        f'Пойдём же дальше в путь, мой добрый друг, на встречу приключениям!',
        reply_markup=markup
    )
    hero = characters.Peasant(health=30, weapon=weapons.stick_nerd, name=hero.name,
                              armor=armors.mage_robe, hero_class='Маг', min_block=1, max_block=2,
                              items=hero.expendables,
                              ability='раскрывает истинную мощь посохов, открывая новые заклинания.'
                              )
    hero.level += 1
    save_hero(message.from_user.id,
              weapon_name=hero.weapon.name,
              armor_name=hero.armor.name,
              level=hero.level,
              health=hero.health,
              hero_class=hero.hero_class,
              expendables=hero.expendables[0].name,
              cash=hero.cash,
              expendables_count=len(hero.expendables),
              defence=hero.defence
              )


# todo: доделать
def become_warrior(message):
    hero_params = get_hero(message.from_user.id)
    hero = characters.Peasant(
        health=hero_params['health'], weapon=weapons.weapons_name[hero_params['weapon_name']], name=hero_params['name'],
        armor=armors.armors_name[hero_params['armor_name']], hero_class=hero_params['hero_class'], min_block=1,
        max_block=2,
        items=[special_items.items_name[hero_params['expendables']] for _ in range(hero_params['expendables_count'])],
        ability='способностей нет'
    )
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    go_btn = types.KeyboardButton('Идти дальше')
    bot.send_message(
        message.chat.id,
        f'Теперь ты воин 1 уровня!',
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        f'Получены новые предметы: Кубомеч и Доспех воина!',
    )
    markup.add(go_btn)
    bot.send_message(
        message.chat.id,
        f'Пойдём же дальше в путь, мой добрый друг, на встречу приключениям!',
        reply_markup=markup
    )
    hero = characters.Peasant(health=35, weapon=weapons.dice_sword, name=hero_params['name'],
                              armor=armors.warrior_armor, hero_class='Воин', min_block=2, max_block=3,
                              items=hero.expendables,
                              ability='делает тебя мастером меча, увеличивает твой урон в 1.5 раз,'
                                      ' если при атаке мечом выпадает дубль.'
                              )
    hero.level += 1
    save_hero(message.from_user.id,
              weapon_name=hero.weapon.name,
              armor_name=hero.armor.name,
              level=hero.level,
              health=hero.health,
              hero_class=hero.hero_class,
              expendables=hero.expendables[0].name,
              cash=hero.cash,
              expendables_count=len(hero.expendables),
              defence=hero.defence
              )


def go_to_tavern(message):
    hero_params = get_hero(message.from_user.id)
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    enter_btn = types.KeyboardButton('Войти в таверну')
    markup.add(enter_btn)
    bot.send_message(
        message.chat.id,
        f'Смотри, {hero_params["name"]}, таверна! Думаю, там можно будет найти то, что поможет тебе в пути.',
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        f'Держи, тебе это тебе понадобится.'
    )
    bot.send_message(
        message.chat.id,
        f'Получено 100 золота!'
    )
    save_one_hero(message.from_user.id, 'cash', 100)
    bot.send_message(
        message.chat.id,
        f'Идём?',
        reply_markup=markup
    )


def tavern(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    view_btn = types.KeyboardButton('Посмотреть товар')
    blocks = get_setting(message.from_user.id)
    asked_btn = types.KeyboardButton('Спросить, что интересного говорят в последнее время')
    if message.text == 'Войти в таверну':
        bot.send_message(
            message.chat.id,
            f'{miss_seller.name}: Добро пожаловать в мою таверну! Чего желаешь, путник?',
            reply_markup=remove
        )
        if blocks['way'] == 'pacifist':
            markup.add(view_btn, asked_btn)
            bot.send_message(
                message.chat.id,
                f'{miss_seller.name}:'
                f' Слышала, ты отличаешься от "сказочных героев", мне такое нравится.\n'
                f'Думаю я могу позволить себе выделить для тебя скидку в 50%, не обеднею.',
                reply_markup=markup
            )
            miss_seller.discount = 50
        else:
            markup.add(view_btn)
            bot.send_message(
                message.chat.id,
                f'{miss_seller.name}:'
                f' Знаешь, в наших краях не все любят героев. Удачи, конечно, на твоём на пути, но ты берегись.',
                reply_markup=markup
            )


def ask(message):
    hero_params = get_hero(message.from_user.id)
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    view_btn = types.KeyboardButton('Посмотреть товар')
    bot.send_message(
        message.chat.id,
        f'{hero_params["name"]}:'
        f' Что интересного ты можешь рассказать?',
        reply_markup=remove
    )
    markup.add(view_btn)
    bot.send_message(
        message.chat.id,
        f'{miss_seller.name}:'
        f' Да в целом все не так плохо, все постепенно привыкают к новой жизни.\n'
        f'Хотя некоторые верят, что вражда ещё не окончена.',
        reply_markup=markup
    )


def view_item(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    view_btn = types.KeyboardButton('Уйти из магазина')
    markup.add(view_btn)
    bot.send_message(
        message.chat.id,
        f'{miss_seller.name}:'
        f' Вот, смотри, бери что хочешь, главное чтоб золотых хватило!',
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        miss_seller.show_items()
    )
    bot.send_message(
        message.chat.id,
        f'Введи название того предмета, который ты хочешь купить.',
        reply_markup=markup
    )
    save_one_set(message.from_user.id, param='in_shop', val=True)


def left_shop(message):
    hero_params = get_hero(message.from_user.id)
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    go_to_the_gate_btn = types.KeyboardButton('Пойти к воротам')
    blocks = get_setting(message.from_user.id)
    if blocks['way'] == 'pacifist':
        bot.send_message(
            message.chat.id,
            f'{hero_params["name"]}: спасибо тебе, {miss_seller.name}, мне пора идти, удачи!'
        )
    bot.send_message(
        message.chat.id,
        f'{miss_seller.name}: до новых встреч, {hero_params["name"]}.',
        reply_markup=remove
    )
    markup.add(go_to_the_gate_btn)
    bot.send_message(
        message.chat.id,
        f'Идём, {hero_params["name"]}, нам пора уходить из деревни.',
        reply_markup=markup
    )


def talk_to_the_guard(message):
    global enemy
    hero_params = get_hero(message.from_user.id)
    enemy = characters.guard
    blocks = get_setting(message.from_user.id)
    if blocks['way'] == 'pacifist':
        bot.send_message(
            message.chat.id,
            f'{enemy.name}: извини, я не смогу пропустить тебя, таковы правила.'
        )
        bot.send_message(
            message.chat.id,
            f'{hero_params["name"]}: тогда и ты меня прости за то, что будет дальше.',
            reply_markup=remove
        )
    elif blocks['way'] == 'murder':
        bot.send_message(
            message.chat.id,
            f'{enemy.name}: ну что ж, я уже слышал о тебе, хорошо, что ты пришёл сам.',
            reply_markup=remove
        )
    start_fight(message)


def finish_off_the_enemy2(message):
    hero_params = get_hero(message.from_user.id)
    bot.send_message(
        message.chat.id,
        f'Ты добил защитника.',
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        f'Ну что ж, {hero_params["name"]}, уходим, мы стали на шаг ближе к цели.'
    )
    bot.send_message(
        message.chat.id,
        f'Поздравляем, вы прошли демо!'
    )


def spare_the_enemy2(message):
    hero_params = get_hero(message.from_user.id)
    bot.send_message(
        message.chat.id,
        f'{hero_params["name"]}: ты мне не враг, прощай.',
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        f'Ну что ж, {hero_params["name"]}, уходим, мы стали на шаг ближе к цели.'
    )
    bot.send_message(
        message.chat.id,
        f'Поздравляем, вы прошли демо!'
    )


# region battle
def create_all_battles_btn(message):
    hero_params = get_hero(message.from_user.id)
    hero = characters.Peasant(
        health=hero_params['health'], weapon=weapons.weapons_name[hero_params['weapon_name']], name=hero_params['name'],
        armor=armors.armors_name[hero_params['armor_name']], hero_class=hero_params['hero_class'], min_block=1,
        max_block=2,
        items=[special_items.items_name[hero_params['expendables']] for _ in range(hero_params['expendables_count'])],
        ability='способностей нет'
    )
    hit_btn = types.KeyboardButton('Ударить')
    spell_btn = types.KeyboardButton('Произнести заклинание')
    enter_combination_btn = types.KeyboardButton('Ввести комбинацию')
    # region inventory
    check_inventory_btn = types.KeyboardButton('Открыть инвентарь')
    # endregion
    block_btn = types.KeyboardButton('Блок')
    check_self_status_btn = types.KeyboardButton('Проверить своё состояние')
    check_enemy_status_btn = types.KeyboardButton('Проверить состояние противника')
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    if type(hero.weapon) == weapons.Staff:
        markup.add(hit_btn, spell_btn)
        markup.add(check_inventory_btn, block_btn)
        markup.add(check_self_status_btn, check_enemy_status_btn)
    elif type(hero.weapon) == weapons.MaceWithShield:
        markup.add(hit_btn, enter_combination_btn)
        markup.add(check_inventory_btn, block_btn)
        markup.add(check_self_status_btn, check_enemy_status_btn)
    else:
        markup.add(hit_btn, check_inventory_btn, block_btn)
        markup.add(check_self_status_btn, check_enemy_status_btn)
    return markup


def spell_cast(message):
    global spells
    spells = list()
    hero_params = get_hero(message.from_user.id)
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    hell_btn = types.KeyboardButton('hell')
    triad_btn = types.KeyboardButton('triad')
    return_btn = types.KeyboardButton('Вернуться к выбору')
    bot.send_message(
        message.chat.id,
        f'Выбери одно из заклинаний, чтобы использовать его.',
        reply_markup=remove
    )
    if hero_params["hero_class"] == 'Маг':
        markup.add(hell_btn)
        spells.append('hell')
        bot.send_message(
            message.chat.id,
            f'hell - заклинание, отнимающее пол жизни у противника с 25% шансом.'
        )
    markup.add(triad_btn)
    spells.append('triad')
    markup.add(return_btn)
    bot.send_message(
        message.chat.id,
        f'triad - заклинание, бьющее соперника три раза с 50% шансом.',
        reply_markup=markup
    )


def enter_combination(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    return_btn = types.KeyboardButton('Вернуться к выбору')
    bot.send_message(
        message.chat.id,
        f'Введи комбинацию, состоящую из 3 слов "удар" и "блок".',
        reply_markup=remove
    )
    markup.add(return_btn)
    bot.send_message(
        message.chat.id,
        f'(Слова разделяй пробелом.\n'
        f'- Добрый Разработчик)',
        reply_markup=markup
    )


def create_inventory(message):
    hero_params = get_hero(message.from_user.id)
    bot.send_message(
        message.chat.id,
        'Хорошо.',
        reply_markup=remove
    )
    # region buttons
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    check_expendables_btn = types.KeyboardButton('Посмотреть расходники')
    check_special_items_btn = types.KeyboardButton('Посмотреть особые предметы')
    check_weapon_btn = types.KeyboardButton('Посмотреть оружие')
    check_armor_btn = types.KeyboardButton('Посмотреть броню')
    buttons = list()
    if hero_params['expendables_count'] != 0:
        buttons.append(check_special_items_btn)
    if hero_params['expendables_count'] != 0:
        buttons.append(check_expendables_btn)
    buttons.append(check_weapon_btn)
    buttons.append(check_armor_btn)
    markup.add(*buttons)
    # endregion
    bot.send_message(
        message.chat.id,
        'Что ты хочешь посмотреть?',
        reply_markup=markup
    )


def check_weapon(message):
    hero_params = get_hero(message.from_user.id)
    hero = characters.Peasant(
        health=hero_params['health'], weapon=weapons.weapons_name[hero_params['weapon_name']], name=hero_params['name'],
        armor=armors.armors_name[hero_params['armor_name']], hero_class=hero_params['hero_class'], min_block=1,
        max_block=2,
        items=[special_items.items_name[hero_params['expendables']] for _ in range(hero_params['expendables_count'])],
        ability='способностей нет'
    )
    bot.send_message(
        message.chat.id,
        hero.weapon.info(),
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        f'Что же ты сделаешь, {hero_params["name"]}?',
        reply_markup=create_all_battles_btn(message)
    )


def check_armor(message):
    hero_params = get_hero(message.from_user.id)
    hero = characters.Peasant(
        health=hero_params['health'], weapon=weapons.weapons_name[hero_params['weapon_name']], name=hero_params['name'],
        armor=armors.armors_name[hero_params['armor_name']], hero_class=hero_params['hero_class'], min_block=1,
        max_block=2,
        items=[special_items.items_name[hero_params['expendables']] for _ in range(hero_params['expendables_count'])],
        ability='способностей нет'
    )
    bot.send_message(
        message.chat.id,
        hero.armor.info(),
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        f'Что же ты сделаешь, {hero_params["name"]}?',
        reply_markup=create_all_battles_btn(message)
    )


def check_enemy(message):
    bot.send_message(
        message.chat.id,
        enemy.check_status()
    )


def first_move_in_fight(message):
    blocks = get_setting(message.from_user.id)
    if blocks['first_move']:
        bot.send_message(
            message.chat.id,
            f'{enemy.name} вступил в бой!'
        )
        save_one_set(message.from_user.id, param='first_move', val=False)
        enemy.doing()
        bot.send_message(
            message.chat.id,
            f'{enemy.action}',
            reply_markup=create_all_battles_btn(message)
        )


def enemy_attack(message):
    hero_params = get_hero(message.from_user.id)
    hero = characters.Peasant(
        health=hero_params['health'], weapon=weapons.weapons_name[hero_params['weapon_name']], name=hero_params['name'],
        armor=armors.armors_name[hero_params['armor_name']], hero_class=hero_params['hero_class'], min_block=1,
        max_block=2,
        items=[special_items.items_name[hero_params['expendables']] for _ in range(hero_params['expendables_count'])],
        ability='способностей нет'
    )
    if enemy.action == f'{enemy.name} готовится нанести удар!':
        enemy_damage = enemy.attack(hero=hero)
        bot.send_message(
            message.chat.id,
            f'{enemy.name} нанёс {enemy_damage} урона!'
            f' Теперь у тебя {hero_params["health"]} жизни и {hero_params["defence"]} брони.'
        )


def enemy_defeat(message):
    hero_params = get_hero(message.from_user.id)
    hero = characters.Peasant(
        health=hero_params['health'], weapon=weapons.weapons_name[hero_params['weapon_name']], name=hero_params['name'],
        armor=armors.armors_name[hero_params['armor_name']], hero_class=hero_params['hero_class'], min_block=1,
        max_block=2,
        items=[special_items.items_name[hero_params['expendables']] for _ in range(hero_params['expendables_count'])],
        ability='способностей нет'
    )
    mercy_btn = types.KeyboardButton('Пощадить')
    finish_of_btn = types.KeyboardButton('Добить')
    bot.send_message(
        message.chat.id,
        f'{enemy.name} повержен.',
        reply_markup=remove
    )
    bot.send_message(
        message.chat.id,
        f'Ваш показатель брони восстановлен.',
    )
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(mercy_btn, finish_of_btn)
    bot.send_message(
        message.chat.id,
        'Добей его, чтобы получить новый уровень и стать ближе к званию "настоящий герой"!',
        reply_markup=markup
    )
    save_one_hero(message.from_user.id, 'defence', hero.base_defence)
    enemy.action = None
    save_one_set(message.from_user.id, param='first_move', val=True)
    save_one_set(message.from_user.id, param='fight_now', val=False)


def check_expendables(message):
    hero_params = get_hero(message.from_user.id)
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    close_inventory = types.KeyboardButton('Закрыть инвентарь')
    markup.add(close_inventory)
    bot.send_message(
        message.chat.id,
        'Вот, всё, что у тебя есть.',
        reply_markup=remove
    )
    for i in range(hero_params['expendables_count']):
        bot.send_message(
            message.chat.id,
            hero_params['expendables']
        )
    bot.send_message(
        message.chat.id,
        f'Введи название того предмета, который ты хочешь использовать',
        reply_markup=markup
    )
    save_one_set(message.from_user.id, param='in_inventory', val=True)


# endregion
# endregion


bot.infinity_polling()
