import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Setting(SqlAlchemyBase):
    __tablename__ = 'setting'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    first_move = sqlalchemy.Column(sqlalchemy.Boolean)
    way = sqlalchemy.Column(sqlalchemy.String)
    first_fight = sqlalchemy.Column(sqlalchemy.Boolean)
    fight_now = sqlalchemy.Column(sqlalchemy.Boolean)
    in_inventory = sqlalchemy.Column(sqlalchemy.Boolean)
    in_shop = sqlalchemy.Column(sqlalchemy.Boolean)

    block_start_game = sqlalchemy.Column(sqlalchemy.Boolean)
    block_name = sqlalchemy.Column(sqlalchemy.Boolean)
    block_story_start = sqlalchemy.Column(sqlalchemy.Boolean)
    block_fight1 = sqlalchemy.Column(sqlalchemy.Boolean)
    block_finish_sparing1 = sqlalchemy.Column(sqlalchemy.Boolean)
    block_choice_class = sqlalchemy.Column(sqlalchemy.Boolean)
    block_go_to_tavern = sqlalchemy.Column(sqlalchemy.Boolean)
    block_tavern = sqlalchemy.Column(sqlalchemy.Boolean)
    block_question = sqlalchemy.Column(sqlalchemy.Boolean)
    block_view_product = sqlalchemy.Column(sqlalchemy.Boolean)
    block_talk_with_guard = sqlalchemy.Column(sqlalchemy.Boolean)
    block_fight2 = sqlalchemy.Column(sqlalchemy.Boolean)

    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="setting")

    def __repr__(self):
        return '<Setting %r>' % self.id