import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Hero(SqlAlchemyBase):
    __tablename__ = 'hero'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String)
    weapon_name = sqlalchemy.Column(sqlalchemy.String)
    armor_name = sqlalchemy.Column(sqlalchemy.String)
    level = sqlalchemy.Column(sqlalchemy.Integer)
    defence = sqlalchemy.Column(sqlalchemy.Integer)
    health = sqlalchemy.Column(sqlalchemy.Integer)
    hero_class = sqlalchemy.Column(sqlalchemy.String)
    expendables = sqlalchemy.Column(sqlalchemy.String)
    expendables_count = sqlalchemy.Column(sqlalchemy.Integer)
    cash = sqlalchemy.Column(sqlalchemy.Integer)

    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="hero")

    def __repr__(self):
        return '<Hero %r>' % self.id