import project_data.game.weapons as weapons
import project_data.game.armors as armors
import project_data.game.special_items as special_items
from random import randint


class Seller:
    def __init__(self, name, cash, discount, **items):
        self.name = name
        self.cash = cash
        self.discount = discount
        self.items = items

    def show_items(self):
        pass


class Enemy:
    def __init__(self, health, weapon, name, armor):
        self.health = health
        self.weapon = weapon
        self.name = name
        self.status = 'alive'
        self.defence = armor.defence
        self.armor = armor
        self.action = None

    def attack(self, hero):
        damage = self.weapon.attack()
        if hero.defence == 0:
            hero.health -= damage
        else:
            hero.defence -= damage
            if hero.defence < 0:
                hero.defence = 0
        return damage

    def check_status(self):
        return f'Имя: {self.name}\n' \
               f'Здоровье: {self.health}\n' \
               f'Урон: {self.weapon.min_damage} - {self.weapon.max_damage}\n' \
               f'Показатель защиты: {self.defence}\n' \
               f'Оружие: {self.weapon.name}\n' \
               f'Броня: {self.armor.name}'

    def doing(self):
        if randint(1, 10) < 7:
            self.action = f'{self.name} готовится нанести удар!'
        else:
            self.action = f'{self.name} отдыхает'
        return self.action


class Peasant:
    def __init__(self, name, weapon, health, armor, hero_class, min_block, max_block, item):
        self.name = name
        self.weapon = weapon
        self.health = health
        self.base_defence = armor.defence
        self.defence = armor.defence
        self.armor = armor
        self.level = 0
        self.status = 'alive'
        self.hero_class = hero_class
        self.special_items = list()
        self.expendables = [item]
        self.cash = 0
        self.min_block = min_block
        self.max_block = max_block
        self.max_health = health
        self.name_expendables = [item.name]

    def attack(self, other):
        damage = self.weapon.attack()
        if other.defence == 0:
            other.health -= damage
        else:
            other.defence -= damage
            if other.defence < 0:
                other.defence = 0
        return damage

    def check_status(self):
        return f'Имя: {self.name}\n' \
               f'Уровень: {self.level}\n' \
               f'Класс: {self.hero_class}\n' \
               f'Здоровье: {self.health} из {self.max_health}\n' \
               f'Показатель защиты: {self.defence} из {self.base_defence}\n' \
               f'Оружие: {self.weapon.name}\n' \
               f'Броня: {self.armor.name}\n' \
               f'Блок: {self.min_block} - {self.max_block}'

    def show_items(self):
        text = list()
        for i in self.special_items:
            text.append(i.show())
        return text

    def show_expendables(self):
        text = list()
        for i in self.expendables:
            text.append(i.info())
        return text

    def use_expendable(self, expendable):
        for i in self.expendables:
            if i.name == expendable:
                i.use(hero)
                self.expendables.remove(i)
                self.name_expendables.remove(expendable)
            break

    def use_block(self):
        return randint(self.min_block, self.max_block)


class Warrior(Peasant):
    def __init__(self, name, weapon, health, armor, hero_class, min_block, max_block, item):
        super().__init__(name, weapon, health, armor, hero_class, min_block, max_block, item)
        self.super = False

    def use_super(self):
        self.super = True


class Mage(Peasant):
    def check_spells(self):
        pass


hero = Peasant(health=25, weapon=weapons.pitchfork, name=None,
               armor=armors.peasants_robe, hero_class='Крестьянин', min_block=1, max_block=2, item=special_items.loaf)
monster = Enemy(health=15, weapon=weapons.monster_fists, name='Монстр', armor=armors.tattered_clothing)
miss_seller = Seller(name='Даша', cash=100, discount=0)
