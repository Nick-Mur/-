from datetime import datetime

from sqlalchemy.exc import IntegrityError

from project_data.db_talesword.data.users import User
from project_data.db_talesword.data.hero import Hero
from project_data.db_talesword.data.enemy import Enemy
from project_data.db_talesword.data.setting import Setting
from project_data.db_talesword.data.boss import Boss


def db_reg_user(userid):
    try:
        from project_data.db_talesword.data import db_session
        db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
        user = User()
        user.userID = userid
        db_sess = db_session.create_session()
        db_sess.add(user)
        db_sess.commit()
        db_sess.close()
    except IntegrityError:
        pass


def insert_nickname_in_table(userid, nickname):
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    hero_name = Hero(name=nickname)
    user.hero.append(hero_name)
    db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def edit_nickname_in_table(userid, nickname):
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    user.created_date = datetime.now()
    user.hero[0].name = nickname
    db_sess.commit()
    db_sess.close()


def db_viewer_nickname(userid):
    """
    Для register_nickname
    """
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    if user.hero:
        db_sess.close()
        return False  # Если сработает - значит не регистрируем
    db_sess.close()
    return True


def get_setting(userid):
    """Выводит значение блоков"""
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    param = {
        'first_move': user.setting[0].first_move,
        'way': user.setting[0].way,
        'first_fight': user.setting[0].first_fight,
        'fight_now': user.setting[0].fight_now,
        'in_inventory': user.setting[0].in_inventory,
        'in_shop': user.setting[0].in_shop,
        'block_start_game': user.setting[0].block_start_game,
        'block_name': user.setting[0].block_name,
        'block_story_start': user.setting[0].block_story_start,
        'block_fight1': user.setting[0].block_fight1,
        'block_finish_sparing1': user.setting[0].block_finish_sparing1,
        'block_choice_class': user.setting[0].block_choice_class,
        'block_go_to_tavern': user.setting[0].block_go_to_tavern,
        'block_tavern': user.setting[0].block_tavern,
        'block_question': user.setting[0].block_question,
        'block_view_product': user.setting[0].block_view_product,
        'block_talk_with_guard': user.setting[0].block_talk_with_guard,
        'block_fight2': user.setting[0].block_fight2
    }
    db_sess.close()
    return param


def get_hero(userid):
    """Выводит значение блоков"""
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    param = {
        'armor_name': user.hero[0].armor_name,
        'weapon_name': user.hero[0].weapon_name,
        'level': user.hero[0].level,
        'health': user.hero[0].health,
        'hero_class': user.hero[0].hero_class,
        'expendables': user.hero[0].expendables,
        'cash': user.hero[0].cash,
        'name': user.hero[0].name,
        'expendables_count': user.hero[0].expendables_count,
        'defence': user.hero[0].defence
    }
    db_sess.close()
    return param


def save_setting(userid, first_move=True, way='pacifist', first_fight=True,
                 fight_now=False, in_inventory=False, in_shop=False,
                 block_start_game=False, block_name=False, block_story_start=False,
                 block_fight1=False, block_finish_sparing1=False, block_choice_class=False,
                 block_go_to_tavern=False, block_tavern=False, block_question=False,
                 block_view_product=False, block_talk_with_guard=False, block_fight2=False):
    """Сохраняет значение блоков"""
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.setting:
        user.setting[0].first_move = first_move
        user.setting[0].way = way
        user.setting[0].first_fight = first_fight
        user.setting[0].fight_now = fight_now
        user.setting[0].in_inventory = in_inventory
        user.setting[0].in_shop = in_shop
        user.setting[0].block_start_game = block_start_game
        user.setting[0].block_name = block_name
        user.setting[0].block_story_start = block_story_start
        user.setting[0].block_fight1 = block_fight1
        user.setting[0].block_finish_sparing1 = block_finish_sparing1
        user.setting[0].block_choice_class = block_choice_class
        user.setting[0].block_go_to_tavern = block_go_to_tavern
        user.setting[0].block_tavern = block_tavern
        user.setting[0].block_question = block_question
        user.setting[0].block_view_product = block_view_product
        user.setting[0].block_talk_with_guard = block_talk_with_guard
        user.setting[0].block_fight2 = block_fight2
    else:
        setting = Setting(
            first_move=first_move,
            way=way,
            first_fight=first_fight,
            fight_now=fight_now,
            in_inventory=in_inventory,
            in_shop=in_shop,
            block_start_game=block_start_game,
            block_name=block_name,
            block_story_start=block_story_start,
            block_fight1=block_fight1,
            block_finish_sparing1=block_finish_sparing1,
            block_choice_class=block_choice_class,
            block_go_to_tavern=block_go_to_tavern,
            block_tavern=block_tavern,
            block_question=block_question,
            block_view_product=block_view_product,
            block_talk_with_guard=block_talk_with_guard,
            block_fight2=block_fight2
        )
        user.setting.append(setting)
        db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def save_hero(userid, weapon_name, armor_name, level, defence,
              health, hero_class, expendables, cash, expendables_count=1):
    """Сохраняет значение блоков"""
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    try:
        user.hero[0].armor_name = armor_name
        user.hero[0].weapon_name = weapon_name
        user.hero[0].level = level
        user.hero[0].health = health
        user.hero[0].hero_class = hero_class
        user.hero[0].expendables = expendables
        user.hero[0].expendables_count = expendables_count
        user.hero[0].cash = cash
        user.hero[0].defence = defence
    except:
        hero = Hero(
            weapon_name=weapon_name,
            armor_name=armor_name,
            level=level,
            health=health,
            hero_class=hero_class,
            expendables='Буханка',
            expendables_count=expendables_count,
            cash=cash,
            defence=defence
        )
        user.hero.append(hero)
        db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def get_enemy(userid):
    """Выводит значение блоков"""
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    param = {
        'defence': user.enemy[0].defence,
        'health': user.enemy[0].health,
        'status': user.enemy[0].status,
        'action': user.enemy[0].action
    }
    db_sess.close()
    return param


def save_enemy(userid, health, status, action, defence):
    """Сохраняет значение блоков"""
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.enemy:
        user.enemy[0].action = action
        user.enemy[0].status = status
        user.enemy[0].health = health
        user.enemy[0].defence = defence
    else:
        enemy = Enemy(
            action=action,
            status=status,
            health=health,
            defence=defence
        )
        user.enemy.append(enemy)
        db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def get_boss(userid):
    """Выводит значение блоков"""
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    param = {
        'defence': user.boss[0].defence,
        'health': user.boss[0].health,
        'status': user.boss[0].status,
        'action': user.boss[0].action
    }
    db_sess.close()
    return param


def save_boss(userid, health, status, action, defence):
    """Сохраняет значение блоков"""
    from project_data.db_talesword.data import db_session
    db_session.global_init("project_data/db_talesword/db/data_talesworlds.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.boss:
        user.boss[0].action = action
        user.boss[0].status = status
        user.boss[0].health = health
        user.boss[0].defence = defence
    else:
        boss = Boss(
            action=action,
            status=status,
            health=health,
            defence=defence
        )
        user.boss.append(boss)
        db_sess.add(user)
    db_sess.commit()
    db_sess.close()
