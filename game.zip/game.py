import characters
import weapons
import armors
MOVE = 0
HERO_CLASS = None


def move():
    global MOVE
    MOVE += 1
    if MOVE == 2:
        MOVE = 0


name = input('Введите своё имя')
if name == '':
    name = 'Герой'

hero = characters.Peasant(health=100, weapon=weapons.start_sword, name=name, defence=5, armor=armors.peasants_robe)
monster = characters.Enemy(health=25, weapon=weapons.monster_fists, name='Монстр')
# вместо "Игрок" будет id игрока
while True:
    print('В этих краях давно водились монстры, разбойники и прочая нечисть.\n'
          'Вы недовольный крестьянин.\n'
          'Вам нужен король, вы хотите высказать ему всё, что у вас накопилось.\n'
          'Для этого пройти долгий и сложный путь.')
    print('Добро пожаловать в деревню, Игрок! Я рассказчик, твой верный друг в этом странном мире. \n'
          'Я всё тебе объясню и покажу!\n'
          'Смотри, это твоё первый враг - тот никудышный монстр, который может кому-то причинить вред!\n'
          'Вступи с ним в бой.')
    # кнопка "вступить в бой"
    print('БООООООЙ!!!')
    # будет кнопка бросить кубик, сделать возможность пощады
    heroes_in_battle = [hero, monster]
    while heroes_in_battle[0].status != 'dead' and heroes_in_battle[1].status != 'dead':
        heroes_in_battle[MOVE].attack(heroes_in_battle[1 - MOVE])
        move()
        print()
    print('Бой закончен')

    print('')
    break
