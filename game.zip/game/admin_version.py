import telebot
import time
import sqlite3
import data.game.armors as armors
import data.game.weapons as weapons
import data.game.special_items as special_items
import data.game.characters as characters
from telebot import types
from data.config import bot_token


# region DB
def create_nickname_table():
    conn = sqlite3.connect('data/database_talesworlds/data_talesworlds.sql')
    cur = conn.cursor()

    cur.execute('''CREATE TABLE IF NOT EXISTS users ( 
    user_id primary key, 
    nickname
    )''')
    conn.commit()
    cur.close()
    conn.close()


def insert_in_database(data: tuple, column: tuple, database: str, table: str):
    """
    Вставляет data в column в файл database в таблицу table
    """
    conn = sqlite3.connect(f'data/database_talesworlds/{database}')
    cur = conn.cursor()

    cur.execute(f'INSERT INTO {table} {column} VALUES {data}', )
    conn.commit()
    cur.close()
    conn.close()


def delete_in_database(data, column: str, database: str, table: str):
    """
    Удаляет data в column в файл database в таблицу table
    """
    conn = sqlite3.connect(f'data/database_talesworlds/{database}')
    cur = conn.cursor()
    try:
        cur.execute(f'DELETE FROM {table} WHERE {data} = {column}')
    except sqlite3.OperationalError:
        pass
    conn.commit()
    cur.close()
    conn.close()


# endregion

# region settings
# telegram bot
bot = telebot.TeleBot(token=bot_token)
create_nickname_table()

# Game
hero = characters.hero
monster = characters.monster
enemy = monster
first_move = True
way = 'pacifist'
# endregion


@bot.message_handler(commands=['start'])
def telegram_start(message):
    markup = types.ReplyKeyboardMarkup()
    start_game_btn = types.KeyboardButton('Начать игру')
    markup.add(start_game_btn)
    bot.send_message(
        message.chat.id,
        f'Здравствуй, {message.from_user.first_name}! Добро пожаловать в мой мир - Talesworld.\n'
        f'Зови меня сказочником или рассказчиком, сейчас я тебе расскажу одну историю. Готов ли ты?',
        reply_markup=markup
    )


@bot.message_handler(content_types=['text'])
def telegram_handler(message):
    """
    Обработка любого отправленного текста
    """
    remove = types.ReplyKeyboardRemove()
    if message.text == 'Начать игру':
        bot.send_message(
            message.chat.id,
            '<b>Введи имя счастливца, что станет центром нашей истории</b>',
            parse_mode='html',
            reply_markup=remove
        )
        bot.register_next_step_handler(message, start_game)


@bot.message_handler(content_types=['text'])
def start_game(message):
    global enemy, first_move
    delete_in_database(
        data=message.from_user.id,
        column='user_id',
        database='data_talesworlds.sql',
        table='users'
    )

    if message.text.isalpha():
        hero.name = message.text

    insert_in_database(
        data=(message.from_user.id, hero.name),
        column=('user_id', 'nickname'),
        database='data_talesworlds.sql',
        table='users'
    )

    bot.send_message(
        message.chat.id,
        'В этих краях давно водились монстры, разбойники и прочая нечисть.\n'
        f'Ты, {hero.name}, недовольный крестьянин.\n'
        'Тебе нужен король, ведь ты хочешь высказать ему всё, что у тебя накопилось.\n'
        'Для этого ты готов пройти долгий и сложный путь.\n'
        'Но не бойся, на протяжении всего пути я буду с тобой.'
    )
    bot.send_message(
        message.chat.id,
        'Итак, пока мы только в "деревне, над которой не садится солнце", а из вещей у тебя только роба, да вилы.\n'
        'Но это ничего, не все великие герои с самого начала были таковыми, так что и тебе не стоит беспокоиться.\n'
        'Главное держись меня, лишь я на твоей стороне.'
    )
    bot.send_message(
        message.chat.id,
        'Смотри, тебе навстречу идёт монстр!\n'
        'Из рассказов, сказок и легенд, ты должен знать, когда монстры приходят в деревни к людям,'
        ' ничем хорошим это не кончается. \n'
        ''
    )
    markup = types.ReplyKeyboardMarkup()
    come_up_btn = types.KeyboardButton('Подойти')
    markup.add(come_up_btn)
    bot.send_message(
        message.chat.id,
        'Иди, разберись с ним!',
        reply_markup=markup
    )
    bot.register_next_step_handler(message, fight_with_enemy1)


@bot.message_handler(content_types=['text'])
def fight_with_enemy1(message):
    global enemy, first_move
    # region buttons
    remove = types.ReplyKeyboardRemove()
    markup = types.ReplyKeyboardMarkup()
    check_self_status_btn = types.KeyboardButton('Проверить своё состояние')
    check_inventory_btn = types.KeyboardButton('Проверить инвентарь')
    hit_btn = types.KeyboardButton('Ударить')
    check_enemy_status_btn = types.KeyboardButton('Проверить состояние противника')
    mercy_btn = types.KeyboardButton('Пощадить')
    finish_of_btn = types.KeyboardButton('Добить')
    markup.add(check_self_status_btn)
    markup.add(check_inventory_btn)
    markup.add(hit_btn)
    markup.add(check_enemy_status_btn)
    # endregion
    if message.text == 'Подойти':
        bot.send_message(
            message.chat.id,
            'FIGHT!!!',
            reply_markup=remove
        )

        bot.send_message(
            message.chat.id,
            f'Что же ты сделаешь, {hero.name}?',
            reply_markup=markup
        )
    if message.text == 'Проверить своё состояние':
        bot.send_message(
            message.chat.id,
            hero.check_status()
        )
    elif message.text == 'Ударить':
        damage = hero.attack(monster)
        bot.send_message(
            message.chat.id,
            f'Ты нанёс {damage} урона! Теперь у {enemy.name} {enemy.health} жизни и {enemy.defence} брони.'
        )
        if first_move:
            bot.send_message(
                message.chat.id,
                f'{enemy.name} вступил в бой!'
            )
        enemy_damage = enemy.attack(hero=hero)
        if monster.health > 0 and not first_move:
            bot.send_message(
                message.chat.id,
                f'{enemy.name} нанёс {enemy_damage} урона!'
                f' Теперь у тебя {hero.health} жизни и {hero.defence} брони.'
            )
        elif monster.health <= 0:
            bot.send_message(
                message.chat.id,
                f'{enemy.name} повержен.',
                reply_markup=remove
            )
            bot.send_message(
                message.chat.id,
                f'Ваш показатель брони восстановлен.',
            )
            markup = types.ReplyKeyboardMarkup()
            markup.add(mercy_btn)
            markup.add(finish_of_btn)
            bot.send_message(
                message.chat.id,
                'Добей его, чтобы получить новый уровень и возможность стать настоящим героем!',
                reply_markup=markup
            )
            hero.defence = hero.base_defence
            bot.register_next_step_handler(message, take_a_decision1)
        if monster.health > 0:
            bot.send_message(
                message.chat.id,
                f'{enemy.name} готовится нанести {enemy.weapon.damage}.'
            )
            first_move = False
    elif message.text == 'Проверить инвентарь':
        text = list()
        text += hero.weapon.check_weapon() + ['\n'] + hero.armor.check_armor()
        text = ''.join(text)
        bot.send_message(
            message.chat.id,
            text
        )
    elif message.text == 'Проверить состояние противника':
        bot.send_message(
            message.chat.id,
            enemy.check_status()
        )
    bot.register_next_step_handler(message, fight_with_enemy1)


@bot.message_handler(content_types=['text'])
def take_a_decision1(message):
    global hero, way
    # region buttons
    remove = types.ReplyKeyboardRemove()
    markup = types.ReplyKeyboardMarkup()
    go_btn = types.KeyboardButton('Идти дальше')
    mage = types.KeyboardButton('Стать магом')
    warrior = types.KeyboardButton('Стать воином')
    # endregion
    # region pacifist
    if message.text == 'Пощадить':
        bot.send_message(
            message.chat.id,
            f'{hero.name}: У меня не было выбора {enemy.name},'
            f' но теперь, когда он у меня есть, я не стану тебя добивать тебя.',
            reply_markup=remove
        )
        bot.send_message(
            message.chat.id,
            f'{enemy.name}: я понимаю, ты ведь герой. Вот, держи, она защитит твою душу!',
        )
        hero.armor.add_special(special=special_items.camomile)
        bot.send_message(
            message.chat.id,
            f'Получен предмет *Ромашка*!',
        )
        bot.send_message(
            message.chat.id,
            f'...',
        )
        markup.add(go_btn)
        bot.send_message(
            message.chat.id,
            f'Что ж, {hero.name}, твой уровень повысился на 0.\n'
            f'В этот раз ты не смог стать настоящим героем, но у тебя ещё будет возможность.',
            reply_markup=markup
        )
        bot.register_next_step_handler(message, new_stage)
    # endregion
    elif message.text == 'Добить':
        enemy.status = 'dead'
        way = 'murder'
        bot.send_message(
            message.chat.id,
            f'Ты добил монстра.',
            reply_markup=remove
        )
        bot.send_message(
            message.chat.id,
            f'Поздравляю, {hero.name}, ты стал НАСТОЯЩИМ героем! Теперь ты герой 1 уровня!',
        )
        bot.send_message(
            message.chat.id,
            f'Уровень повышен на 1.',
        )
        markup.add(mage)
        markup.add(warrior)
        bot.send_message(
            message.chat.id,
            f'И теперь, так как ты стал героем, ты можешь выбрать себе класс и получить новое оружие!',
            reply_markup=markup
        )
    elif message.text == 'Стать магом':
        bot.send_message(
            message.chat.id,
            f'Теперь ты маг 1 уровня!',
            reply_markup=remove
        )
        bot.send_message(
            message.chat.id,
            f'Получены новые предметы: Посох мага и Роба мага!',
        )
        markup.add(go_btn)
        bot.send_message(
            message.chat.id,
            f'Пойдём же дальше в путь, мой добрый друг, на встречу приключениям!',
            reply_markup=markup
        )
        hero = characters.Mage(health=25, weapon=weapons.start_staff, name=hero.name,
                               armor=armors.mage_robe, hero_class='Маг')
        bot.register_next_step_handler(message, new_stage)
    elif message.text == 'Стать воином':
        bot.send_message(
            message.chat.id,
            f'Теперь ты воин 1 уровня!',
            reply_markup=remove
        )
        bot.send_message(
            message.chat.id,
            f'Получены новые предметы: Меч воина и Доспех воина!',
        )
        markup.add(go_btn)
        bot.send_message(
            message.chat.id,
            f'Пойдём же дальше в путь, мой добрый друг, на встречу приключениям!',
            reply_markup=markup
        )
        hero = characters.Mage(health=30, weapon=weapons.start_sword, name=hero.name,
                               armor=armors.warrior_armor, hero_class='Воин')
        bot.register_next_step_handler(message, new_stage)
    bot.register_next_step_handler(message, take_a_decision1)


@bot.message_handler(content_types=['text'])
def new_stage(message):
    remove = types.ReplyKeyboardRemove()
    if message.text == 'Идти дальше':
        bot.send_message(
            message.chat.id,
            f'Пока всё :)',
            reply_markup=remove
        )


bot.infinity_polling()
