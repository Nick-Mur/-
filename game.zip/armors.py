class CommonArmor:
    def __init__(self, defence):
        self.defence = defence


peasants_robe = CommonArmor(5)
